export const environment = {
  production: true,
  baseUrl: 'http://192.168.1.6:6789' // TODO Application tier URL
};
