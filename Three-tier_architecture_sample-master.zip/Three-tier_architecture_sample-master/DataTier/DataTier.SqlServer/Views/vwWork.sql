﻿CREATE VIEW [dbo].[vwWork]
	AS 
	SELECT *
	FROM [dbo].[Work]
