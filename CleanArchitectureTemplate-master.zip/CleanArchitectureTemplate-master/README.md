# CleanArchitectureTemplate
Project template featuring Onion Architecture, CQRS + MediatR, UoW &amp; Repository Pattern, Specification Pattern, FluentValidation, DDD, TDD, BDD.
