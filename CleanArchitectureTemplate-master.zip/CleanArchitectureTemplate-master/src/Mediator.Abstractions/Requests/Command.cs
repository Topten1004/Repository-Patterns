﻿
using Mediator.Abstractions.Interfaces.Commands;

namespace Mediator.Abstractions.Requests
{
    public class Command<T> : ICommand<T>
    {
    }
}
