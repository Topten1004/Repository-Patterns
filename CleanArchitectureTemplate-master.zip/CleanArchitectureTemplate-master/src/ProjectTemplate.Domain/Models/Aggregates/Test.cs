﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectTemplate.Domain.Models.Aggregates
{
    public class Test
    {
    }
}
