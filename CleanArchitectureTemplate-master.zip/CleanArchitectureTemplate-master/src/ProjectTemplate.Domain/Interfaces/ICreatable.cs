﻿using System;


namespace ProjectTemplate.Domain.Interfaces
{
    public interface ICreatable
    {
        DateTime CreatedOn { get; }
    }
}
