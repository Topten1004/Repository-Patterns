﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectTemplate.Domain.Interfaces
{
    public interface IAggregateRoot : IEntity
    {
    }
}
