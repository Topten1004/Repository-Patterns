﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectTemplate.Persistence.Queries.Features.Test
{
    class TestQueryValidator
    {
    }
}
