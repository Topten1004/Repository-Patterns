# Repository_UnitOfWork_Example
This is just the basic framework of a DDD project using the Repository &amp; UnitOfWork pattern.
