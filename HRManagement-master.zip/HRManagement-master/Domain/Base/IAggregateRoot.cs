﻿namespace Domain.Base
{
    public interface IAggregateRoot
    {
    }
}