﻿namespace API.Extensions
{
    public static class ApplicationBuilderExtensions
    {
    }
}