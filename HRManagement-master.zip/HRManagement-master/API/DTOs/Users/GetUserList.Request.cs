﻿namespace API.DTOs.Users
{
    public class GetUserRequest
    {
        public string Search { get; set; }
    }
}