﻿namespace API.DTOs.Users
{
    public class UpdateUserResponse
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
}