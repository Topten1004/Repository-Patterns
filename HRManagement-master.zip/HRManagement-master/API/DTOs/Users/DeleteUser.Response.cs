﻿namespace API.DTOs.Users
{
    public class DeleteUserResponse
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
}