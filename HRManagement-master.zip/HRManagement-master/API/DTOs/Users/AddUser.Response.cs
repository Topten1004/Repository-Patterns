﻿namespace API.DTOs.Users
{
    public class AddUserResponse
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
}