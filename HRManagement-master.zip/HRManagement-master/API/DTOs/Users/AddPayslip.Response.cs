﻿namespace API.DTOs.Users
{
    public class AddPayslipResponse
    {
        public int UserId { get; set; }

        public decimal TotalSalary { get; set; }
    }
}