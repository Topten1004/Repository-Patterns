﻿namespace API.DTOs.Users
{
    public class DeleteUserRequest
    {
        public int Id { get; set; }
    }
}